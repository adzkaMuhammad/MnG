import {useEffect,useRef,useState} from 'react'
import {sb} from './supabase'

const EM=['❤️','😂','😮','😢','😡','👍']
const tm=t=>{const d=new Date(t);return d.toDateString()===new Date().toDateString()?d.toLocaleTimeString([],{hour:'2-digit',minute:'2-digit'}):d.toLocaleDateString([],{day:'numeric',month:'short'})}
const sz=b=>b>1e6?(b/1e6).toFixed(1)+' MB':Math.ceil(b/1e3)+' KB'
const mmss=s=>Math.floor(s/60)+':'+String(s%60).padStart(2,'0')

function Av({p,g,s}){return <div className={'av'+(s?' s':'')+(g?' g':'')}>{p?.avatar_url?<img src={p.avatar_url} alt=""/>:g?'👥':(p?.username||'?')[0].toUpperCase()}</div>}

function Auth(){
  const [mode,setMode]=useState('in'),[email,setEmail]=useState(''),[pw,setPw]=useState(''),[un,setUn]=useState(''),[err,setErr]=useState(''),[busy,setBusy]=useState(false)
  const go=async e=>{
    e.preventDefault();setBusy(true);setErr('')
    const r=mode==='in'?await sb.auth.signInWithPassword({email,password:pw}):await sb.auth.signUp({email,password:pw,options:{data:{username:un.trim().toLowerCase()}}})
    if(r.error)setErr(r.error.message);else if(mode==='up'&&!r.data.session)setErr('Cek email untuk konfirmasi, atau matikan "Confirm email" di Supabase.')
    setBusy(false)
  }
  return <form className="auth" onSubmit={go}>
    <h1>Direct</h1>
    {mode==='up'&&<input placeholder="Username" value={un} onChange={e=>setUn(e.target.value)} pattern="[a-zA-Z0-9_.]{3,20}" required/>}
    <input type="email" placeholder="Email" value={email} onChange={e=>setEmail(e.target.value)} required/>
    <input type="password" placeholder="Kata sandi (min. 6 karakter)" value={pw} onChange={e=>setPw(e.target.value)} minLength={6} required/>
    <button className="btn" disabled={busy}>{mode==='in'?'Masuk':'Daftar'}</button>
    {err&&<p className="err">{err}</p>}
    <button type="button" className="lnk" onClick={()=>setMode(mode==='in'?'up':'in')}>{mode==='in'?'Belum punya akun? Daftar':'Sudah punya akun? Masuk'}</button>
  </form>
}

function Picker({P,me,exclude=[],cta,onDone,groupName}){
  const [q,setQ]=useState(''),[sel,setSel]=useState([]),[name,setName]=useState('')
  const list=Object.values(P).filter(p=>p.id!==me&&!exclude.includes(p.id)&&p.username.includes(q.toLowerCase()))
  const tog=id=>setSel(s=>s.includes(id)?s.filter(x=>x!==id):[...s,id])
  return <>
    <input className="srch" placeholder="Cari…" value={q} onChange={e=>setQ(e.target.value)}/>
    <div className="plist">{list.map(p=><label key={p.id} className="row"><Av p={p} s/><span>{p.username}</span><input type="checkbox" checked={sel.includes(p.id)} onChange={()=>tog(p.id)}/></label>)}
      {!list.length&&<p className="mt">Tidak ada pengguna.</p>}</div>
    {groupName&&sel.length>1&&<input className="srch" placeholder="Nama grup" value={name} onChange={e=>setName(e.target.value)}/>}
    <button className="btn" disabled={!sel.length} onClick={()=>onDone(sel,name)}>{cta}</button>
  </>
}

function Modal({title,close,children}){
  return <div className="ov" onClick={e=>e.target===e.currentTarget&&close()}><div className="sheet"><div className="sh"><b>{title}</b><button onClick={close}>✕</button></div>{children}</div></div>
}

function Thread({conv,me,P,tick,back,title,reload}){
  const [M,setM]=useState([]),[R,setR]=useState([]),[txt,setTxt]=useState(''),[reply,setReply]=useState(null),[sel,setSel]=useState(null)
  const [info,setInfo]=useState(false),[add,setAdd]=useState(false),[rec,setRec]=useState(null),[sec,setSec]=useState(0),[up,setUp]=useState(false)
  const end=useRef(),cancel=useRef(false),fi=useRef(),id=conv.id,g=conv.is_group
  const mine=conv.members.find(m=>m.user_id===me),isAdmin=mine?.role==='admin'
  const other=!g&&P[conv.members.find(m=>m.user_id!==me)?.user_id]

  useEffect(()=>{setReply(null);setSel(null);setInfo(false)},[id])
  useEffect(()=>{(async()=>{
    const {data}=await sb.from('messages').select('*').eq('conversation_id',id).order('created_at').limit(400)
    setM(data||[]);const ids=(data||[]).map(m=>m.id)
    if(ids.length){const r=await sb.from('reactions').select('*').in('message_id',ids);setR(r.data||[])}else setR([])
  })()},[id,tick])
  useEffect(()=>{end.current?.scrollIntoView()},[M.length,id])
  useEffect(()=>{if(mine&&new Date(mine.last_read_at)<new Date(conv.last_message_at))sb.from('members').update({last_read_at:new Date().toISOString()}).eq('conversation_id',id).eq('user_id',me).then(()=>{})},[tick,id])
  useEffect(()=>{if(!rec)return;setSec(0);const t=setInterval(()=>setSec(s=>s+1),1000);return()=>clearInterval(t)},[rec])

  const send=async f=>{
    const {error}=await sb.from('messages').insert({conversation_id:id,sender_id:me,reply_to:reply?.id||null,...f})
    if(error)alert(error.message);setReply(null)
  }
  const sendText=()=>{const b=txt.trim();if(!b)return;setTxt('');send({kind:'text',body:b})}
  const upload=async(file,kind,extra={})=>{
    setUp(true)
    const path=`${me}/${crypto.randomUUID()}-${file.name.replace(/[^\w.-]/g,'_')}`
    const {error}=await sb.storage.from('media').upload(path,file,{contentType:file.type||'application/octet-stream'})
    if(error){setUp(false);return alert(error.message)}
    await send({kind,media_url:sb.storage.from('media').getPublicUrl(path).data.publicUrl,media_name:file.name,media_size:file.size,...extra});setUp(false)
  }
  const pick=e=>{for(const f of e.target.files)upload(f,f.type.startsWith('image/')?'image':f.type.startsWith('video/')?'video':'file');e.target.value=''}
  const toggleRec=async()=>{
    if(rec){rec.stop();return}
    try{
      const st=await navigator.mediaDevices.getUserMedia({audio:true}),mr=new MediaRecorder(st),ch=[],t0=Date.now();cancel.current=false
      mr.ondataavailable=e=>ch.push(e.data)
      mr.onstop=()=>{st.getTracks().forEach(t=>t.stop());setRec(null);if(cancel.current)return
        const ext=mr.mimeType.includes('mp4')?'m4a':'webm';upload(new File([new Blob(ch,{type:mr.mimeType})],'voice.'+ext,{type:mr.mimeType}),'audio',{duration:Math.round((Date.now()-t0)/1000)})}
      mr.start();setRec(mr)
    }catch{alert('Izin mikrofon ditolak.')}
  }
  const react=async(m,e)=>{
    const ex=R.find(r=>r.message_id===m.id&&r.user_id===me)
    if(ex?.emoji===e)await sb.from('reactions').delete().match({message_id:m.id,user_id:me});else await sb.from('reactions').upsert({message_id:m.id,user_id:me,emoji:e})
    setSel(null)
  }
  const unsend=async m=>{setSel(null);await sb.from('messages').update({deleted:true,body:null,media_url:null}).eq('id',m.id)}
  const rename=async v=>{if(v.trim()&&v!==conv.name)await sb.from('conversations').update({name:v.trim()}).eq('id',id)}
  const leave=async()=>{if(!confirm('Keluar dari chat ini?'))return;await sb.from('members').delete().match({conversation_id:id,user_id:me});back();reload()}
  const kick=async u=>{if(confirm('Keluarkan anggota ini?'))await sb.from('members').delete().match({conversation_id:id,user_id:u})}
  const addMembers=async ids=>{await sb.from('members').insert(ids.map(u=>({conversation_id:id,user_id:u})));setAdd(false)}

  const Body=({m})=>m.deleted?<i>Pesan ditarik</i>
    :m.kind==='image'?<a href={m.media_url} target="_blank" rel="noreferrer"><img className="mi" src={m.media_url} alt=""/></a>
    :m.kind==='video'?<video className="mi" src={m.media_url} controls playsInline/>
    :m.kind==='audio'?<span className="vn"><audio src={m.media_url} controls/><small>{mmss(m.duration||0)}</small></span>
    :m.kind==='file'?<a className="fl" href={m.media_url} target="_blank" rel="noreferrer" download>📄 <span>{m.media_name}<small>{sz(m.media_size||0)}</small></span></a>
    :m.body
  const lastMine=[...M].reverse().find(m=>m.sender_id===me)
  const seenBy=lastMine?conv.members.filter(x=>x.user_id!==me&&new Date(x.last_read_at)>=new Date(lastMine.created_at)).map(x=>P[x.user_id]?.username):[]
  const media=M.filter(m=>!m.deleted&&(m.kind==='image'||m.kind==='video'))

  return <div className="thread">
    <header><button className="ic bk" onClick={back}>←</button><Av p={other} g={g} s/><b className="grow">{title}</b><button className="ic" onClick={()=>setInfo(true)}>ⓘ</button></header>
    <div className="msgs" onClick={e=>e.target.classList.contains('msgs')&&setSel(null)}>
      {M.map((m,i)=>{
        const me_=m.sender_id===me,prev=M[i-1],showName=g&&!me_&&prev?.sender_id!==m.sender_id
        const rp=m.reply_to&&M.find(x=>x.id===m.reply_to),rx=R.filter(r=>r.message_id===m.id)
        const media_=!m.deleted&&(m.kind==='image'||m.kind==='video')
        return <div key={m.id}>
          {(!prev||new Date(m.created_at)-new Date(prev.created_at)>36e5)&&<div className="ts">{tm(m.created_at)}</div>}
          <div className={'r'+(me_?' me':'')}>
            {g&&!me_&&<Av p={P[m.sender_id]} s/>}
            <div className="c">
              {showName&&<div className="nm">{P[m.sender_id]?.username}</div>}
              {rp&&<div className="rp">↩ {P[rp.sender_id]?.username}: {rp.deleted?'Pesan ditarik':rp.body||'Lampiran'}</div>}
              <div className={'b'+(m.deleted?' un':'')+(media_?' im':'')} onDoubleClick={()=>!m.deleted&&react(m,'❤️')} onClick={()=>setSel(sel===m.id?null:m.id)}><Body m={m}/></div>
              {rx.length>0&&<div className="rx">{rx.map(r=>r.emoji).join('')}{rx.length>1&&' '+rx.length}</div>}
              {sel===m.id&&!m.deleted&&<div className="act">
                {EM.map(e=><button key={e} onClick={()=>react(m,e)}>{e}</button>)}
                <button onClick={()=>{setReply(m);setSel(null)}}>↩</button>
                {m.kind==='text'&&<button onClick={()=>{navigator.clipboard?.writeText(m.body);setSel(null)}}>⧉</button>}
                {me_&&<button onClick={()=>unsend(m)}>🗑</button>}
              </div>}
            </div>
          </div>
        </div>})}
      {lastMine&&seenBy.length>0&&<div className="ts">{g?'Dilihat oleh '+seenBy.join(', '):'Dilihat'}</div>}
      <div ref={end}/>
    </div>
    {reply&&<div className="rpb"><span>Membalas {P[reply.sender_id]?.username}: {reply.body||'Lampiran'}</span><button onClick={()=>setReply(null)}>✕</button></div>}
    <div className="bar">
      {rec?<>
        <button className="ic" onClick={()=>{cancel.current=true;rec.stop()}}>🗑</button>
        <span className="grow recd">● {mmss(sec)}</span><button className="pk" onClick={toggleRec}>Kirim</button>
      </>:<>
        <button className="ic" onClick={()=>fi.current.click()} disabled={up}>📎</button>
        <input ref={fi} type="file" multiple hidden onChange={pick}/>
        <input className="in" placeholder={up?'Mengunggah…':'Pesan…'} value={txt} onChange={e=>setTxt(e.target.value)} onKeyDown={e=>e.key==='Enter'&&sendText()}/>
        {txt.trim()?<button className="pk" onClick={sendText}>Kirim</button>:<button className="ic" onClick={toggleRec}>🎤</button>}
      </>}
    </div>

    {info&&<Modal title="Detail" close={()=>setInfo(false)}>
      <div className="ctr"><Av p={other} g={g}/>
        {g?<input className="gname" defaultValue={conv.name} onBlur={e=>rename(e.target.value)}/>:<><b>{other?.username}</b></>}
      </div>
      {g&&<>
        <div className="sec">Anggota ({conv.members.length}){isAdmin&&<button className="pk" onClick={()=>setAdd(true)}>Tambah</button>}</div>
        {conv.members.map(m=><div key={m.user_id} className="row"><Av p={P[m.user_id]} s/><span className="grow">{P[m.user_id]?.username}{m.user_id===me&&' (Anda)'}{m.role==='admin'&&<small> · Admin</small>}</span>
          {isAdmin&&m.user_id!==me&&<button className="pk red" onClick={()=>kick(m.user_id)}>Keluarkan</button>}</div>)}
      </>}
      <div className="sec">Media ({media.length})</div>
      <div className="grid">{media.map(m=>m.kind==='image'?<a key={m.id} href={m.media_url} target="_blank" rel="noreferrer"><img src={m.media_url} alt=""/></a>:<video key={m.id} src={m.media_url}/>)}</div>
      {g&&<button className="lnk red" onClick={leave}>Keluar dari chat</button>}
    </Modal>}
    {add&&<Modal title="Tambah anggota" close={()=>setAdd(false)}><Picker P={P} me={me} exclude={conv.members.map(m=>m.user_id)} cta="Tambahkan" onDone={addMembers}/></Modal>}
  </div>
}

function Main({me}){
  const [P,setP]=useState({}),[C,setC]=useState([]),[N,setN]=useState({}),[cur,setCur]=useState(null),[tick,setTick]=useState(0),[modal,setModal]=useState(null),[nt,setNt]=useState('')
  const timer=useRef()
  const load=async()=>{
    const [p,c,n]=await Promise.all([sb.from('profiles').select('*'),sb.from('conversations').select('*,members(user_id,role,last_read_at)').order('last_message_at',{ascending:false}),sb.from('notes').select('*')])
    setP(Object.fromEntries((p.data||[]).map(x=>[x.id,x])));setC(c.data||[]);setN(Object.fromEntries((n.data||[]).map(x=>[x.user_id,x])));setTick(t=>t+1)
  }
  useEffect(()=>{
    load();const ch=sb.channel('all')
    ;['messages','reactions','members','conversations','notes','profiles'].forEach(t=>ch.on('postgres_changes',{event:'*',schema:'public',table:t},()=>{clearTimeout(timer.current);timer.current=setTimeout(load,150)}))
    ch.subscribe();return()=>{sb.removeChannel(ch)}
  },[])
  const title=c=>c.is_group?c.name:P[c.members.find(m=>m.user_id!==me)?.user_id]?.username||'…'
  const conv=C.find(c=>c.id===cur)
  const myNote=N[me]&&Date.now()-new Date(N[me].created_at)<864e5?N[me]:null
  const startChat=async(ids,name)=>{
    const r=ids.length===1?await sb.rpc('create_dm',{other:ids[0]}):await sb.rpc('create_group',{gname:name.trim()||'Grup baru',uids:ids})
    if(r.error)return alert(r.error.message);setModal(null);await load();setCur(r.data)
  }
  const saveNote=async()=>{
    const t=nt.trim();if(t)await sb.from('notes').upsert({user_id:me,text:t.slice(0,60),created_at:new Date().toISOString()});else await sb.from('notes').delete().eq('user_id',me)
    setModal(null)
  }
  return <div className={'app'+(cur?' open':'')}>
    <aside>
      <header><b className="grow">{P[me]?.username}</b><button className="ic" onClick={()=>setModal('new')}>✎</button><button className="ic" onClick={()=>sb.auth.signOut()}>⎋</button></header>
      <div className="notes">
        <div className="nt" onClick={()=>{setNt(myNote?.text||'');setModal('note')}}><div className="bb">{myNote?myNote.text:'Catatan baru'}</div><Av p={P[me]}/><span>Catatanmu</span></div>
        {Object.values(N).filter(n=>n.user_id!==me&&Date.now()-new Date(n.created_at)<864e5).map(n=><div key={n.user_id} className="nt"><div className="bb">{n.text}</div><Av p={P[n.user_id]}/><span>{P[n.user_id]?.username}</span></div>)}
      </div>
      <div className="sec">Pesan</div>
      <div className="list">
        {C.map(c=>{const un=c.last_message&&c.last_sender!==me&&new Date(c.members.find(m=>m.user_id===me)?.last_read_at)<new Date(c.last_message_at)
          const o=!c.is_group&&P[c.members.find(m=>m.user_id!==me)?.user_id]
          return <button key={c.id} className={'ch'+(un?' un':'')+(c.id===cur?' act':'')} onClick={()=>setCur(c.id)}><Av p={o} g={c.is_group}/>
            <div className="t"><b>{title(c)}</b><small>{c.last_message?(c.last_sender===me?'Anda: ':'')+c.last_message+' · '+tm(c.last_message_at):'Mulai chat'}</small></div>{un&&<i className="dot"/>}</button>})}
        {!C.length&&<p className="mt">Belum ada chat. Tekan ✎ untuk mulai.</p>}
      </div>
    </aside>
    <main>{conv?<Thread conv={conv} me={me} P={P} tick={tick} title={title(conv)} back={()=>setCur(null)} reload={load}/>
      :<div className="empty"><div className="ring">✈</div><h2>Pesan Anda</h2><p>Kirim pesan pribadi atau buat grup.</p><button className="btn" onClick={()=>setModal('new')}>Kirim pesan</button></div>}</main>
    {modal==='new'&&<Modal title="Pesan baru" close={()=>setModal(null)}><Picker P={P} me={me} cta="Chat" groupName onDone={startChat}/></Modal>}
    {modal==='note'&&<Modal title="Catatan" close={()=>setModal(null)}>
      <input className="srch" maxLength={60} placeholder="Bagikan sesuatu… (60 karakter, hilang dalam 24 jam)" value={nt} onChange={e=>setNt(e.target.value)} autoFocus/>
      <button className="btn" onClick={saveNote}>{nt.trim()?'Bagikan':'Hapus catatan'}</button></Modal>}
  </div>
}

export default function App(){
  const [ses,setSes]=useState(undefined)
  useEffect(()=>{sb.auth.getSession().then(({data})=>setSes(data.session));const {data}=sb.auth.onAuthStateChange((_,s)=>setSes(s));return()=>data.subscription.unsubscribe()},[])
  if(ses===undefined)return null
  return ses?<Main me={ses.user.id}/>:<Auth/>
}
