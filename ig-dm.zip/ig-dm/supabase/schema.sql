-- Jalankan seluruh file ini di Supabase > SQL Editor
create table profiles(id uuid primary key references auth.users on delete cascade,username text unique not null,avatar_url text,created_at timestamptz default now());
create table conversations(id uuid primary key default gen_random_uuid(),is_group boolean default false,name text,created_by uuid references profiles(id),created_at timestamptz default now(),last_message_at timestamptz default now(),last_message text,last_sender uuid);
create table members(conversation_id uuid references conversations on delete cascade,user_id uuid references profiles on delete cascade,role text default 'member',last_read_at timestamptz default now(),primary key(conversation_id,user_id));
create table messages(id uuid primary key default gen_random_uuid(),conversation_id uuid not null references conversations on delete cascade,sender_id uuid not null references profiles(id),kind text not null default 'text' check(kind in('text','image','video','audio','file')),body text,media_url text,media_name text,media_size bigint,duration int,reply_to uuid references messages(id) on delete set null,deleted boolean default false,created_at timestamptz default now());
create table reactions(message_id uuid references messages on delete cascade,user_id uuid references profiles on delete cascade,emoji text not null,primary key(message_id,user_id));
create table notes(user_id uuid primary key references profiles on delete cascade,text text check(char_length(text)<=60),created_at timestamptz default now());
create index on messages(conversation_id,created_at);

create function is_member(cid uuid) returns boolean language sql security definer stable set search_path=public as $$select exists(select 1 from members where conversation_id=cid and user_id=auth.uid())$$;
create function is_admin(cid uuid) returns boolean language sql security definer stable set search_path=public as $$select exists(select 1 from members where conversation_id=cid and user_id=auth.uid() and role='admin')$$;

create function create_dm(other uuid) returns uuid language plpgsql security definer set search_path=public as $$
declare cid uuid;
begin
 select c.id into cid from conversations c where not c.is_group
  and exists(select 1 from members where conversation_id=c.id and user_id=auth.uid())
  and exists(select 1 from members where conversation_id=c.id and user_id=other) limit 1;
 if cid is null then
  insert into conversations(created_by) values(auth.uid()) returning id into cid;
  insert into members(conversation_id,user_id,role) values(cid,auth.uid(),'admin'),(cid,other,'member');
 end if; return cid;
end$$;

create function create_group(gname text,uids uuid[]) returns uuid language plpgsql security definer set search_path=public as $$
declare cid uuid;
begin
 insert into conversations(is_group,name,created_by) values(true,gname,auth.uid()) returning id into cid;
 insert into members(conversation_id,user_id,role) values(cid,auth.uid(),'admin');
 insert into members(conversation_id,user_id) select distinct u from unnest(uids) u where u<>auth.uid();
 return cid;
end$$;

create function on_message() returns trigger language plpgsql security definer set search_path=public as $$
begin
 update conversations set last_message_at=new.created_at,last_sender=new.sender_id,
  last_message=case new.kind when 'text' then left(new.body,80) when 'image' then '📷 Foto' when 'video' then '🎥 Video' when 'audio' then '🎤 Pesan suara' else '📄 '||coalesce(new.media_name,'File') end
 where id=new.conversation_id; return new;
end$$;
create trigger t_msg after insert on messages for each row execute function on_message();

create function on_signup() returns trigger language plpgsql security definer set search_path=public as $$
begin insert into profiles(id,username) values(new.id,lower(coalesce(new.raw_user_meta_data->>'username',split_part(new.email,'@',1)))); return new; end$$;
create trigger t_signup after insert on auth.users for each row execute function on_signup();

alter table profiles enable row level security;alter table conversations enable row level security;alter table members enable row level security;
alter table messages enable row level security;alter table reactions enable row level security;alter table notes enable row level security;

create policy p_sel on profiles for select to authenticated using(true);
create policy p_upd on profiles for update to authenticated using(id=auth.uid());
create policy c_sel on conversations for select to authenticated using(is_member(id));
create policy c_upd on conversations for update to authenticated using(is_member(id));
create policy m_sel on members for select to authenticated using(is_member(conversation_id));
create policy m_add on members for insert to authenticated with check(is_admin(conversation_id));
create policy m_upd on members for update to authenticated using(user_id=auth.uid());
create policy m_del on members for delete to authenticated using(user_id=auth.uid() or is_admin(conversation_id));
create policy g_sel on messages for select to authenticated using(is_member(conversation_id));
create policy g_ins on messages for insert to authenticated with check(sender_id=auth.uid() and is_member(conversation_id));
create policy g_upd on messages for update to authenticated using(sender_id=auth.uid());
create policy r_sel on reactions for select to authenticated using(is_member((select conversation_id from messages where id=message_id)));
create policy r_ins on reactions for insert to authenticated with check(user_id=auth.uid() and is_member((select conversation_id from messages where id=message_id)));
create policy r_upd on reactions for update to authenticated using(user_id=auth.uid());
create policy r_del on reactions for delete to authenticated using(user_id=auth.uid());
create policy n_sel on notes for select to authenticated using(true);
create policy n_ins on notes for insert to authenticated with check(user_id=auth.uid());
create policy n_upd on notes for update to authenticated using(user_id=auth.uid());
create policy n_del on notes for delete to authenticated using(user_id=auth.uid());

insert into storage.buckets(id,name,public,file_size_limit) values('media','media',true,52428800) on conflict do nothing;
create policy s_ins on storage.objects for insert to authenticated with check(bucket_id='media' and (storage.foldername(name))[1]=auth.uid()::text);
create policy s_sel on storage.objects for select using(bucket_id='media');

alter publication supabase_realtime add table messages,reactions,members,conversations,notes,profiles;
